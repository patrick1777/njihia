export { default } from './People';

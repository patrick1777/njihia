export { default } from './Post';

# Pages

This folder contains React components that are rendering Pages off the application and components that are not reusable and are being used only in specific Page.

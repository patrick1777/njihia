# GraphQL

This folder contains all Queries and Mutations that are used for fetching or writing data from Frontend.

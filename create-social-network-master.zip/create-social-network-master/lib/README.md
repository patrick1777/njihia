# Create Social Network NPM Package

This package includes Node.js command line script that is published to NPM as a `create-social-network`.

This CLI tool helps users to install Social Network App locally with one command.
